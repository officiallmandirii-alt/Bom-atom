import { Router, type IRouter } from "express";
import healthRouter from "./health";
import smtpRouter from "./smtp";
import emailRouter from "./email";
import sendEmailRouter from "./sendEmail";
import settingsRouter from "./settings";

const router: IRouter = Router();

router.use(healthRouter);
router.use(smtpRouter);
router.use(emailRouter);
router.use(sendEmailRouter);
router.use(settingsRouter);

export default router;
