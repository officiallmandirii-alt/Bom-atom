import { Router } from "express";
import nodemailer from "nodemailer";
import { logger } from "../lib/logger";

const router = Router();

const SMTP_PRESETS = [
  {
    name: "Gmail",
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    notes: "Gunakan App Password (bukan password biasa). Aktifkan 2FA dulu di akun Google.",
  },
  {
    name: "Gmail (SSL)",
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    notes: "Gunakan App Password. Port 465 dengan SSL.",
  },
  {
    name: "Yahoo Mail",
    host: "smtp.mail.yahoo.com",
    port: 587,
    secure: false,
    notes: "Gunakan App Password dari pengaturan keamanan Yahoo.",
  },
  {
    name: "Outlook / Hotmail",
    host: "smtp-mail.outlook.com",
    port: 587,
    secure: false,
    notes: "Gunakan password akun Microsoft biasa.",
  },
  {
    name: "Office 365",
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    notes: "Untuk akun Microsoft 365 / bisnis.",
  },
  {
    name: "Zoho Mail",
    host: "smtp.zoho.com",
    port: 587,
    secure: false,
    notes: "Gunakan password akun Zoho.",
  },
  {
    name: "iCloud Mail",
    host: "smtp.mail.me.com",
    port: 587,
    secure: false,
    notes: "Buat App-Specific Password di appleid.apple.com.",
  },
  {
    name: "Custom SMTP",
    host: "",
    port: 587,
    secure: false,
    notes: "Masukkan server SMTP Anda sendiri.",
  },
];

router.get("/smtp/presets", (_req, res) => {
  res.json(SMTP_PRESETS);
});

router.post("/smtp/test", async (req, res) => {
  const { host, port, user, pass, secure } = req.body as {
    host: string;
    port: number;
    user: string;
    pass: string;
    secure?: boolean | null;
  };

  if (!host || !user || !pass) {
    res.status(400).json({ error: "Host, username, dan password wajib diisi." });
    return;
  }

  const useSecure = secure != null ? secure : Number(port) === 465;

  const transporter = nodemailer.createTransport({
    host,
    port: Number(port) || 587,
    secure: useSecure,
    auth: { user, pass },
    connectionTimeout: 10000,
    greetingTimeout: 10000,
  });

  try {
    await transporter.verify();
    logger.info({ host, port, user: user.split("@")[0] + "@***" }, "SMTP connection verified");
    res.json({ success: true, message: "Koneksi SMTP berhasil! Server siap mengirim email." });
  } catch (err: unknown) {
    const error = err as Error;
    logger.warn({ host, port, err: error.message }, "SMTP connection test failed");
    res.json({
      success: false,
      message: "Koneksi gagal: " + error.message,
      details: error.message,
    });
  } finally {
    transporter.close();
  }
});

export default router;
