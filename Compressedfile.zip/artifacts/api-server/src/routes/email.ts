import { Router } from "express";
import nodemailer from "nodemailer";
import { db } from "@workspace/db";
import { emailLogsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { logger } from "../lib/logger";

const router = Router();

router.post("/email/send", async (req, res) => {
  const { to, subject, html, text, smtp } = req.body as {
    to: string;
    subject: string;
    html?: string | null;
    text?: string | null;
    smtp: {
      host: string;
      port: number;
      user: string;
      pass: string;
      name?: string | null;
      secure?: boolean | null;
    };
  };

  if (!to || !subject || !smtp?.user || !smtp?.pass || !smtp?.host) {
    res.status(400).json({
      error: "Field 'to', 'subject', dan konfigurasi SMTP (host, user, pass) wajib diisi.",
    });
    return;
  }

  const useSecure = smtp.secure != null ? smtp.secure : Number(smtp.port) === 465;
  const fromName = smtp.name || smtp.user;

  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: Number(smtp.port) || 587,
    secure: useSecure,
    auth: { user: smtp.user, pass: smtp.pass },
    connectionTimeout: 15000,
    greetingTimeout: 10000,
  });

  try {
    const info = await transporter.sendMail({
      from: `"${fromName}" <${smtp.user}>`,
      to,
      subject,
      text: text || undefined,
      html: html || undefined,
    });

    logger.info({ messageId: info.messageId, to, host: smtp.host }, "Email sent successfully");

    await db.insert(emailLogsTable).values({
      to,
      subject,
      status: "success",
      error: null,
      smtpHost: smtp.host,
      senderName: smtp.name || null,
    });

    res.json({
      success: true,
      message: "Email berhasil terkirim ke " + to,
      messageId: info.messageId,
    });
  } catch (err: unknown) {
    const error = err as Error;
    logger.error({ err: error.message, to, host: smtp.host }, "Failed to send email");

    try {
      await db.insert(emailLogsTable).values({
        to,
        subject,
        status: "failed",
        error: error.message,
        smtpHost: smtp.host,
        senderName: smtp.name || null,
      });
    } catch (dbErr) {
      logger.warn({ err: dbErr }, "Failed to log email error to DB");
    }

    res.status(500).json({
      error: "Gagal mengirim email: " + error.message,
      details: error.message,
    });
  } finally {
    transporter.close();
  }
});

router.get("/email/history", async (req, res) => {
  try {
    const logs = await db
      .select()
      .from(emailLogsTable)
      .orderBy(desc(emailLogsTable.sentAt))
      .limit(50);

    res.json(logs.map((log) => ({
      id: log.id,
      to: log.to,
      subject: log.subject,
      status: log.status,
      error: log.error,
      sentAt: log.sentAt.toISOString(),
      smtpHost: log.smtpHost,
      senderName: log.senderName,
    })));
  } catch (err) {
    logger.error({ err }, "Failed to fetch email history");
    res.status(500).json({ error: "Gagal mengambil riwayat email." });
  }
});

export default router;
