import { Router } from "express";
import nodemailer from "nodemailer";
import { db } from "@workspace/db";
import { emailLogsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router = Router();

router.options("/send-email", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.sendStatus(200);
});

router.post("/send-email", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

  const namaPengirimDefault = "";

  try {
    const body = req.body as Record<string, unknown>;
    const { to, subject, html, text } = body as {
      to?: string;
      subject?: string;
      html?: string;
      text?: string;
    };

    // Support both 'smtp' and 'smtpConfig' field names, same as original
    const smtpSettings = (body["smtpConfig"] || body["smtp"] || {}) as Record<string, unknown>;

    // Support semua variasi field name untuk nama pengirim
    const fromName =
      (smtpSettings["name"] as string) ||
      (smtpSettings["nama"] as string) ||
      (smtpSettings["fromName"] as string) ||
      (smtpSettings["senderName"] as string) ||
      namaPengirimDefault;

    // Support semua variasi field name untuk kredensial SMTP
    const smtpUser =
      (smtpSettings["user"] as string) ||
      (smtpSettings["username"] as string) ||
      (smtpSettings["email"] as string) ||
      (smtpSettings["Username / Email"] as string) ||
      (process.env["SMTP_USER"] as string);

    const smtpPass =
      (smtpSettings["pass"] as string) ||
      (smtpSettings["password"] as string) ||
      (smtpSettings["passwd"] as string) ||
      (smtpSettings["App Password"] as string) ||
      (process.env["SMTP_PASS"] as string);

    const smtpHost =
      (smtpSettings["host"] as string) ||
      (smtpSettings["Host"] as string) ||
      (smtpSettings["server"] as string) ||
      (process.env["SMTP_HOST"] as string);

    const smtpPort = Number(
      (smtpSettings["port"] as string) ||
      (smtpSettings["Port"] as string) ||
      process.env["SMTP_PORT"] ||
      587
    );

    if (!smtpUser || !smtpPass) {
      res.status(400).json({
        error: "Username atau Password SMTP belum diisi!",
        received: {
          smtpUser: smtpUser ? "***" : "EMPTY",
          smtpPass: smtpPass ? "***" : "EMPTY",
        },
      });
      return;
    }

    // Auto-detect secure: true jika port 465, false untuk 587/25/2525
    const useSecure = smtpPort === 465;

    const transporter = nodemailer.createTransport({
      host: smtpHost || "",
      port: smtpPort,
      secure: useSecure,
      auth: { user: smtpUser, pass: smtpPass },
      connectionTimeout: 15000,
      greetingTimeout: 10000,
    });

    await transporter.sendMail({
      from: `"${fromName}" <${smtpUser}>`,
      to,
      subject: subject || "Tanpa Subjek",
      text: text || "",
      html: html || "",
    });

    logger.info({ to, host: smtpHost }, "Email sent via /api/send-email");

    // Simpan ke riwayat
    try {
      await db.insert(emailLogsTable).values({
        to: to || "",
        subject: subject || "Tanpa Subjek",
        status: "success",
        error: null,
        smtpHost: smtpHost || "",
        senderName: fromName || null,
      });
    } catch (_dbErr) {
      // Log tapi jangan gagalkan response
    }

    res.setHeader("Content-Type", "application/json");
    res.json({
      success: true,
      message: "Email berhasil terkirim dengan nama: " + fromName,
    });
  } catch (e: unknown) {
    const error = e as Error;
    logger.error({ err: error.message }, "Failed to send email via /api/send-email");

    try {
      const body = req.body as Record<string, unknown>;
      const smtpSettings = (body["smtpConfig"] || body["smtp"] || {}) as Record<string, unknown>;
      const to = (body["to"] as string) || "";
      const subject = (body["subject"] as string) || "";
      await db.insert(emailLogsTable).values({
        to,
        subject,
        status: "failed",
        error: error.message,
        smtpHost: (smtpSettings["host"] as string) || "",
        senderName: null,
      });
    } catch (_dbErr) {
      // ignore
    }

    res.setHeader("Content-Type", "application/json");
    res.status(500).json({ error: error.message, stack: error.stack });
  } finally {
    // transporter already closed in send path
  }
});

export default router;
