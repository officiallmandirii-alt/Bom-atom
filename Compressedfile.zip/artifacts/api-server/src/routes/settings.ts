import { Router } from "express";
import { db, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";

const router = Router();

const DEFAULT_PASSCODE = "Panel123";
const PASSCODE_KEY = "admin_passcode";

async function getPasscode(): Promise<string> {
  try {
    const rows = await db
      .select()
      .from(settingsTable)
      .where(eq(settingsTable.key, PASSCODE_KEY))
      .limit(1);
    return rows[0]?.value ?? DEFAULT_PASSCODE;
  } catch {
    return DEFAULT_PASSCODE;
  }
}

router.get("/settings/passcode", async (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const passcode = await getPasscode();
  res.json({ passcode });
});

router.post("/settings/passcode/verify", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const { passcode } = req.body as { passcode?: string };
  if (!passcode) {
    res.status(400).json({ valid: false, error: "Passcode wajib diisi." });
    return;
  }
  const actual = await getPasscode();
  res.json({ valid: passcode === actual });
});

router.post("/settings/passcode", async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const { currentPasscode, newPasscode } = req.body as {
    currentPasscode?: string;
    newPasscode?: string;
  };

  if (!currentPasscode || !newPasscode) {
    res.status(400).json({ error: "currentPasscode dan newPasscode wajib diisi." });
    return;
  }

  if (newPasscode.length < 4) {
    res.status(400).json({ error: "Passcode baru minimal 4 karakter." });
    return;
  }

  const actual = await getPasscode();
  if (currentPasscode !== actual) {
    res.status(401).json({ error: "Passcode saat ini salah." });
    return;
  }

  try {
    await db
      .insert(settingsTable)
      .values({ key: PASSCODE_KEY, value: newPasscode })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: { value: newPasscode, updatedAt: new Date() },
      });

    logger.info("Admin passcode updated");
    res.json({ success: true, message: "Passcode berhasil diperbarui." });
  } catch (err) {
    logger.error({ err }, "Failed to update passcode");
    res.status(500).json({ error: "Gagal menyimpan passcode." });
  }
});

export default router;
