import { useState } from "react";
import { useTestSmtp, useGetSmtpPresets, SmtpConfig } from "@workspace/api-client-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Server, ShieldCheck, ShieldAlert } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface SmtpSettingsProps {
  config: SmtpConfig;
  onChange: (config: SmtpConfig) => void;
}

export function SmtpSettings({ config, onChange }: SmtpSettingsProps) {
  const { data: presets } = useGetSmtpPresets();
  const testMutation = useTestSmtp();
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const handlePresetChange = (presetName: string) => {
    if (presetName === "custom") return;
    const preset = presets?.find((p) => p.name === presetName);
    if (preset) {
      onChange({
        ...config,
        host: preset.host,
        port: preset.port,
        secure: preset.secure,
      });
      setTestResult(null);
    }
  };

  const handleTest = async () => {
    try {
      const res = await testMutation.mutateAsync({ data: config });
      setTestResult({ success: res.success, message: res.message });
      if (res.success) {
        toast({ title: "Connection Successful", description: "SMTP settings are valid." });
      } else {
        toast({ title: "Connection Failed", description: res.message, variant: "destructive" });
      }
    } catch (error: any) {
      setTestResult({ success: false, message: error?.message || "Connection failed" });
      toast({ title: "Connection Failed", description: "Could not reach SMTP server", variant: "destructive" });
    }
  };

  return (
    <Card className="border-border">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2">
          <Server className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">SMTP Configuration</CardTitle>
        </div>
        <CardDescription>Server details for outbound relay</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Provider Preset</Label>
          <Select onValueChange={handlePresetChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select provider (Optional)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="custom">Custom Server</SelectItem>
              {presets?.map((preset) => (
                <SelectItem key={preset.name} value={preset.name}>
                  {preset.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2 space-y-2">
            <Label htmlFor="host">Host</Label>
            <Input
              id="host"
              placeholder="smtp.example.com"
              value={config.host}
              onChange={(e) => { onChange({ ...config, host: e.target.value }); setTestResult(null); }}
              className="font-mono text-sm"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="port">Port</Label>
            <Input
              id="port"
              type="number"
              placeholder="587"
              value={config.port}
              onChange={(e) => { onChange({ ...config, port: parseInt(e.target.value) || 587 }); setTestResult(null); }}
              className="font-mono text-sm"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="user">Username / Email</Label>
          <Input
            id="user"
            placeholder="user@example.com"
            value={config.user}
            onChange={(e) => { onChange({ ...config, user: e.target.value }); setTestResult(null); }}
            className="font-mono text-sm"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="pass">Password</Label>
          <Input
            id="pass"
            type="password"
            placeholder="••••••••"
            value={config.pass}
            onChange={(e) => { onChange({ ...config, pass: e.target.value }); setTestResult(null); }}
            className="font-mono text-sm"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="name">Sender Name (Optional)</Label>
          <Input
            id="name"
            placeholder="John Doe"
            value={config.name || ""}
            onChange={(e) => { onChange({ ...config, name: e.target.value }); setTestResult(null); }}
          />
        </div>

        <div className="flex items-center justify-between pt-2">
          <div className="space-y-0.5">
            <Label>Secure (SSL/TLS)</Label>
            <p className="text-xs text-muted-foreground">Force secure connection</p>
          </div>
          <Switch
            checked={!!config.secure}
            onCheckedChange={(checked) => { onChange({ ...config, secure: checked }); setTestResult(null); }}
          />
        </div>
      </CardContent>
      <CardFooter className="flex-col items-stretch gap-4 pt-4 border-t border-border bg-secondary/30">
        <Button 
          variant="outline" 
          onClick={handleTest} 
          disabled={testMutation.isPending || !config.host || !config.user}
          className="w-full font-mono"
        >
          {testMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          TEST CONNECTION
        </Button>
        
        {testResult && (
          <div className={`flex items-start gap-2 text-sm p-3 rounded-md ${testResult.success ? 'bg-green-500/10 text-green-500' : 'bg-destructive/10 text-destructive'}`}>
            {testResult.success ? <ShieldCheck className="w-4 h-4 mt-0.5" /> : <ShieldAlert className="w-4 h-4 mt-0.5" />}
            <span className="font-mono text-xs">{testResult.message}</span>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
