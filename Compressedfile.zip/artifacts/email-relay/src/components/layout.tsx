import { Link, useLocation } from "wouter";
import { Mail, History, Terminal } from "lucide-react";
import { useEffect } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-border bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Terminal className="w-5 h-5 text-primary mr-3" />
          <span className="font-mono font-semibold tracking-tight">G-SWIFT RELAY</span>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          <Link href="/" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${location === "/" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>
            <Mail className="w-4 h-4 mr-3" />
            Compose
          </Link>
          <Link href="/history" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${location === "/history" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>
            <History className="w-4 h-4 mr-3" />
            History
          </Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6 md:p-8 max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
