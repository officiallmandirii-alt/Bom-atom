import { useSendEmail, SmtpConfig, getGetEmailHistoryQueryKey } from "@workspace/api-client-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Send, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useQueryClient } from "@tanstack/react-query";

const composeSchema = z.object({
  to: z.string().min(1, "Recipient is required"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
});

type ComposeFormValues = z.infer<typeof composeSchema>;

interface ComposeFormProps {
  smtpConfig: SmtpConfig;
}

export function ComposeForm({ smtpConfig }: ComposeFormProps) {
  const sendMutation = useSendEmail();
  const queryClient = useQueryClient();

  const form = useForm<ComposeFormValues>({
    resolver: zodResolver(composeSchema),
    defaultValues: {
      to: "",
      subject: "",
      body: "",
    },
  });

  const onSubmit = async (data: ComposeFormValues) => {
    if (!smtpConfig.host || !smtpConfig.user || !smtpConfig.pass) {
      toast({
        title: "Missing SMTP Configuration",
        description: "Please configure your SMTP settings before sending.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await sendMutation.mutateAsync({
        data: {
          to: data.to,
          subject: data.subject,
          text: data.body, // simple text fallback
          html: data.body.replace(/\n/g, "<br />"), // simple HTML conversion
          smtp: smtpConfig,
        },
      });

      if (result.success) {
        toast({
          title: "Email Sent",
          description: result.message,
        });
        form.reset();
        // Invalidate history to refresh the list
        queryClient.invalidateQueries({ queryKey: getGetEmailHistoryQueryKey() });
      } else {
        toast({
          title: "Send Failed",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error?.message || "An unexpected error occurred while sending.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="border-border h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-lg">Compose Message</CardTitle>
        <CardDescription>Draft and dispatch email via relay</CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex-1 flex flex-col">
          <CardContent className="space-y-4 flex-1">
            <FormField
              control={form.control}
              name="to"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>To</FormLabel>
                  <FormControl>
                    <Input placeholder="recipient@example.com, other@example.com" {...field} className="font-mono text-sm" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="subject"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Subject</FormLabel>
                  <FormControl>
                    <Input placeholder="Message Subject" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="body"
              render={({ field }) => (
                <FormItem className="flex-1 flex flex-col">
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Type your message here..." 
                      className="flex-1 min-h-[200px] resize-none font-mono text-sm" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="pt-4 border-t border-border bg-secondary/10">
            <Button 
              type="submit" 
              className="w-full font-mono" 
              disabled={sendMutation.isPending}
            >
              {sendMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Send className="w-4 h-4 mr-2" />
              )}
              DISPATCH
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
