import { useState, useEffect } from "react";
import { SmtpConfig } from "@workspace/api-client-react";

const defaultSmtp: SmtpConfig = {
  host: "",
  port: 587,
  user: "",
  pass: "",
  name: "",
  secure: false,
};

export function useSmtpConfig() {
  const [config, setConfig] = useState<SmtpConfig>(() => {
    try {
      const stored = localStorage.getItem("gswift-smtp-config");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Failed to parse smtp config from local storage", e);
    }
    return defaultSmtp;
  });

  useEffect(() => {
    localStorage.setItem("gswift-smtp-config", JSON.stringify(config));
  }, [config]);

  return [config, setConfig] as const;
}
