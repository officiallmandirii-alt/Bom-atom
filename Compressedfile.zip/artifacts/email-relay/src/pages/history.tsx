import { useGetEmailHistory } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export function History() {
  const { data: history, isLoading } = useGetEmailHistory();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-semibold tracking-tight">Send History</h1>
        <p className="text-muted-foreground text-sm mt-1">Logs of recent email dispatch attempts.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Sends</CardTitle>
          <CardDescription>View status and details of previously sent emails</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : !history || history.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No emails sent yet.</p>
            </div>
          ) : (
            <div className="rounded-md border border-border overflow-hidden">
              <Table>
                <TableHeader className="bg-secondary/50">
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Sent At</TableHead>
                    <TableHead>SMTP Host</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {history.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>
                        {log.status === "success" ? (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20 font-mono text-xs">
                            <CheckCircle2 className="w-3 h-3 mr-1" /> Success
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 font-mono text-xs">
                            <AlertCircle className="w-3 h-3 mr-1" /> Failed
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="font-medium text-sm">{log.to}</TableCell>
                      <TableCell className="text-sm max-w-[200px] truncate" title={log.subject}>
                        {log.subject}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs font-mono">
                        {format(new Date(log.sentAt), "MMM d, yyyy HH:mm:ss")}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs font-mono">
                        {log.smtpHost}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
