import { useSmtpConfig } from "@/hooks/use-smtp-config";
import { SmtpSettings } from "@/components/smtp-settings";
import { ComposeForm } from "@/components/compose-form";

export function Home() {
  const [config, setConfig] = useSmtpConfig();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-semibold tracking-tight">Compose Email</h1>
        <p className="text-muted-foreground text-sm mt-1">Configure SMTP relay and dispatch a new message.</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-1">
          <SmtpSettings config={config} onChange={setConfig} />
        </div>
        <div className="xl:col-span-2">
          <ComposeForm smtpConfig={config} />
        </div>
      </div>
    </div>
  );
}
